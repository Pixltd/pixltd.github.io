export default [
  'Definitely',
  'I have decided upon',
  'I would choose',
  'I\'d go with',
  'In my opinion, it\'s',
  'It\'s absolutely',
  'My final decision is',
  'The answer is',
  'You\'re better off with'
];
