module.exports = {
  // *Required* Prefix for commands.
  PREFIX: '*Kit, ',
  PORT: 6379,

  // *Required* Bot token. Can be found in your bots application page.
  // https://discordapp.com/developers/applications/me
  TOKEN: 'MjQ2NDM5NTYxNzQ2NTc5NDU3.CwkS8A.OIDgSfTrhWSIwVAVQQRkercKrUA',

  // *Required* Bot client ID. Can be found in your bots application page.
  // https://discordapp.com/developers/applications/me
  CLIENT_ID: '246439561746579457',

  // *Required* Redis URL
  // Learn more here. http://redis.io/topics/quickstart
  REDIS_URL: '127.0.0.1',

  // Time to wait between commands per user in seconds. Default is 1.
  MESSAGE_TTL: '',

  // Youtube API key, used for searching videos with `!youtube`.
  // Learn more here. https://developers.google.com/youtube/v3/getting-started
  YOUTUBE_KEY: '',

  // Imgflip username and password, used for creating memes with `!meme`.
  // Create an account here. https://imgflip.com
  IMGFLIP_USERNAME: '',
  IMGFLIP_PASSWORD: '',

  // Champion.gg API key, used for the League of Legends `!lol` commands.
  // Create a key here. http://api.champion.gg/
  CHAMPIONGG_KEY: '',

  // Riot's API key, used for player and match search commands.
  // BE WARNED, a development key will be very limited and most of the time will not work,
  // as there is a lot of requests made in order to complete these data sets.
  RIOT_KEY: '',

  // Wolfram Alpha API key, used to query Wolfram Alpha with `!wolfram`.
  // Apply for a key here. http://products.wolframalpha.com/developers/
  WOLFRAM_KEY: 'HPELKL-764A2A57H5',

  // PasteBin API key, used to create pastes with `!paste`.
  // Get a key here. http://pastebin.com/api/
  PASTEBIN_KEY: '',

  // Popkey API key, used for searching GIFs with `!popkey`.
  // Apply for a key here. http://popkey.co/api/submit
  POPKEY_KEY: '',

  // Random.org API key, used for getting random numbers and strings with `!random`.
  // Get a key here. https://api.random.org/api-keys
  RANDOM_KEY: '',

  // Carbon and Discord Bots key, used for displaying server count on specific websites.
  // More information here. https://www.carbonitex.net/discord/bots & https://bots.discord.pw/api
  CARBON_KEY: '',
  DBOTS_KEY: '',

  // Feedback Channel ID, used for storing feedback with `!feedback`.
  FEEDBACK_CHANNEL_ID: ''
};
